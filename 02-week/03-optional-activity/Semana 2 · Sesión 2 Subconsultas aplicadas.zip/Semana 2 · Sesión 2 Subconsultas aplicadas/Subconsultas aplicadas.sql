DROP DATABASE IF EXISTS repaso_semana2;
CREATE DATABASE repaso_semana2;
USE repaso_semana2;


CREATE TABLE alumno (
  id_alumno INT AUTO_INCREMENT PRIMARY KEY,
  nombre    VARCHAR(80)  NOT NULL,
  correo    VARCHAR(120) UNIQUE
);

CREATE TABLE materia (
  id_materia INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(100) NOT NULL,
  creditos   INT NOT NULL
);

CREATE TABLE inscripcion (
  id_inscripcion  INT AUTO_INCREMENT PRIMARY KEY,
  id_alumno       INT NOT NULL,
  id_materia      INT NOT NULL,
  periodo         VARCHAR(10) NOT NULL,      -- Ej: 2026-2
  nota_final      DECIMAL(4,2) NULL,         -- Ej: 3.75 (0.00 a 5.00)
  fecha_registro  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_alumno)  REFERENCES alumno(id_alumno),
  FOREIGN KEY (id_materia) REFERENCES materia(id_materia)
);


INSERT INTO alumno (nombre, correo) VALUES
('Luis Herrera',   'luis@uni.edu'),
('María Gómez',    'maria@uni.edu'),
('Sofía Rojas',    'sofia@uni.edu'),
('Juan Pineda',    'juan@uni.edu'),
('Valentina Cruz', 'valentina@uni.edu');

INSERT INTO materia (nombre, creditos) VALUES
('Bases de Datos II', 3),
('Programación II',   4),
('Estadística',       3),
('Redes II',          3);

INSERT INTO inscripcion (id_alumno, id_materia, periodo, nota_final, fecha_registro) VALUES
(1, 1, '2026-2', 4.10, '2026-08-01 10:05:00'),
(1, 2, '2026-2', 3.95, '2026-08-02 09:10:00'),
(2, 1, '2026-2', 3.60, '2026-08-01 11:25:00'),
(2, 4, '2026-2', 4.20, '2026-08-03 14:35:00'),
(3, 1, '2026-2', 4.75, '2026-08-02 16:15:00'),
(3, 3, '2026-2', 3.40, '2026-08-04 08:45:00'),
(4, 2, '2026-2', 2.85, '2026-08-02 12:20:00'),
(5, 3, '2026-1', 4.30, '2026-03-15 09:30:00');  


SELECT
  i.periodo,
  al.id_alumno,
  al.nombre    AS alumno,
  m.id_materia,
  m.nombre     AS materia,
  i.nota_final,
  i.fecha_registro
FROM inscripcion i
INNER JOIN alumno  al ON al.id_alumno  = i.id_alumno
INNER JOIN materia m  ON m.id_materia  = i.id_materia
WHERE i.periodo = '2026-2'
ORDER BY m.nombre, al.nombre;


SELECT
  al.id_alumno,
  al.nombre
FROM alumno al
LEFT JOIN inscripcion i
  ON i.id_alumno = al.id_alumno
 AND i.periodo   = '2026-2'
WHERE i.id_inscripcion IS NULL
ORDER BY al.nombre;


SELECT
  m.id_materia,
  m.nombre AS materia,
  COUNT(*) AS total_inscripciones
FROM inscripcion i
INNER JOIN materia m ON m.id_materia = i.id_materia
WHERE i.periodo = '2026-2'
GROUP BY m.id_materia, m.nombre
HAVING COUNT(*) > 2
ORDER BY total_inscripciones DESC, m.nombre;
